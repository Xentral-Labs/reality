"""Shared operational finance services."""
