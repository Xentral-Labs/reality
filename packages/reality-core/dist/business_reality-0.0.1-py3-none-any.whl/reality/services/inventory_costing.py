"""Private bounded inventory implementation behind the shared costing services."""

from dataclasses import asdict
from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from reality.db.core import (
    BusinessEvent,
    Item,
    Movement,
    MovementCorrection,
    Party,
    SourceRecord,
    now,
)
from reality.db.costing import CostReceiptBasis
from reality.db.inventory_costing import (
    CostInventoryMember,
    CostInventoryReview,
    CostMovementBasis,
    CostOwnershipRevision,
    CostPolicyRevision,
)
from reality.domain.costing import InventoryBatchReview, InventoryReview
from reality.domain.inventory_costing import (
    ALGORITHM_VERSION,
    InventoryEvent,
    InventoryRefusal,
    calculate_inventory,
)
from reality.services import core
from reality.services.costing import _hash, _money, _new, _row, _sequence, receipt_cost

MAX_MOVEMENTS = 100
MAX_RECEIPTS = 20
KINDS = {"receipt": "receipt", "shipment": "issue", "transfer": "transfer"}


def _check(
    session: Session,
    tenant: str,
    request: InventoryReview,
    *,
    movement_limit: int | None = None,
    receipt_limit: int | None = None,
) -> dict:
    movement_limit = MAX_MOVEMENTS if movement_limit is None else movement_limit
    receipt_limit = MAX_RECEIPTS if receipt_limit is None else receipt_limit
    if session.connection().get_isolation_level() != "READ COMMITTED":
        raise core.InvalidOperation(
            "Inventory admission requires READ COMMITTED input capture."
        )
    item = _row(session, Item, tenant, request.item_id)
    _row(session, Party, tenant, request.owner_party_id)
    if request.base_unit != item.unit or request.effective_at > now():
        raise core.InvalidOperation("Unsupported inventory base unit or future cutoff.")
    movements = list(
        session.scalars(
            select(Movement)
            .where(
                Movement.tenant_id == tenant,
                Movement.item_id == item.id,
                Movement.occurred_at <= request.effective_at,
            )
            .order_by(Movement.occurred_at, Movement.id)
            .limit(movement_limit + 1)
        )
    )
    if len(movements) > movement_limit:
        raise core.InvalidOperation("Inventory movement bound exceeded.")
    ids = [m.id for m in movements]
    if session.scalar(
        select(MovementCorrection.id)
        .where(
            MovementCorrection.tenant_id == tenant,
            or_(
                MovementCorrection.original_movement_id.in_(ids),
                MovementCorrection.compensating_movement_id.in_(ids),
                MovementCorrection.replacement_movement_id.in_(ids),
            ),
        )
        .limit(1)
    ):
        raise core.InvalidOperation(
            "Inventory scope contains corrected movements; normalization is not yet supported."
        )
    if not movements or any(m.occurred_at < request.history_start for m in movements):
        raise core.InvalidOperation(
            "Inventory history does not support the declared empty opening."
        )
    if any(
        m.type not in KINDS or m.quantity <= 0 or m.resolves_movement_id
        for m in movements
    ):
        raise core.InvalidOperation(
            "Inventory history contains unsupported movement kinds."
        )
    receipt_ids = {m.id for m in movements if m.type == "receipt"}
    if len(receipt_ids) > receipt_limit:
        raise core.InvalidOperation("Inventory receipt bound exceeded.")
    if receipt_ids != {r.movement_id for r in request.receipts}:
        raise core.InvalidOperation(
            "Every receipt requires exact cost and ownership evidence."
        )
    if {m.id for m in movements if m.type == "shipment"} != set(
        request.economic_issue_ids
    ):
        raise core.InvalidOperation(
            "Explicit economic consumption must cover every shipment exactly."
        )
    received = {}
    for chosen in request.receipts:
        _row(session, SourceRecord, tenant, chosen.ownership_source_record_id)
        current = receipt_cost(session, tenant, chosen.movement_id)
        frozen = receipt_cost(
            session, tenant, chosen.movement_id, manifest_id=chosen.manifest_id
        )
        if (
            current["manifest_id"] != chosen.manifest_id
            or frozen["actual_cost"] is None
            or set(current["missing_basis"]) - {"review_stale"}
            or {p["attribution_revision_id"] for p in current["trace"]}
            != {p["attribution_revision_id"] for p in frozen["trace"]}
        ):
            raise core.InvalidOperation(
                "A new complete receipt review is required before inventory confirmation."
            )
        if (
            frozen["currency"] != request.currency
            or frozen["base_unit"] != request.base_unit
        ):
            raise core.InvalidOperation(
                "Inventory receipt currency/base unit is incompatible."
            )
        received[chosen.movement_id] = {
            "receipt_basis_id": frozen["receipt_basis_id"],
            "manifest_id": chosen.manifest_id,
            "ownership_source_record_id": chosen.ownership_source_record_id,
            "cost": frozen["actual_cost"],
            "quantity": frozen["base_quantity"],
        }
    inputs = []
    for movement in movements:
        events = list(
            session.scalars(
                select(BusinessEvent)
                .where(
                    BusinessEvent.tenant_id == tenant,
                    BusinessEvent.event_type == "movement.recorded",
                    BusinessEvent.subject_type == "movement",
                    BusinessEvent.subject_id == movement.id,
                    BusinessEvent.sequence <= request.expected_event_sequence,
                )
                .limit(2)
            )
        )
        if len(events) != 1:
            raise core.InvalidOperation(
                "Inventory movement requires one exact recorded event."
            )
        previous = session.scalar(
            select(CostMovementBasis).where(
                CostMovementBasis.tenant_id == tenant,
                CostMovementBasis.movement_id == movement.id,
            )
        )
        if previous and (
            previous.base_quantity != movement.quantity
            or previous.base_unit != request.base_unit
            or previous.occurred_at != movement.occurred_at
            or previous.movement_type != movement.type
            or previous.movement_event_id != events[0].id
        ):
            raise core.InvalidOperation("Admitted inventory movement input changed.")
        receipt = received.get(movement.id)
        if receipt and Decimal(receipt["quantity"]) != movement.quantity:
            raise core.InvalidOperation(
                "Receipt cost quantity differs from inventory input."
            )
        inputs.append(
            {
                "movement_id": movement.id,
                "movement_type": movement.type,
                "quantity": str(movement.quantity),
                "occurred_at": movement.occurred_at.isoformat(),
                "movement_event_id": events[0].id,
                "sequence": events[0].sequence,
                "acquisition_cost": receipt["cost"] if receipt else None,
            }
        )
    calculated = _calculate(inputs)
    return {
        "acquisition_value": _money(calculated.remaining_cost),
        "remaining_quantity": _money(calculated.remaining_quantity),
        "consumption": _format([asdict(issue) for issue in calculated.issues]),
        "movement_count": len(inputs),
        "receipt_count": len(received),
        "movements": inputs,
        "receipts": received,
    }


def _calculate(inputs: list[dict]):
    try:
        return calculate_inventory(
            [
                InventoryEvent(
                    movement_id=m["movement_id"],
                    kind=KINDS[m["movement_type"]],
                    quantity=Decimal(m["quantity"]),
                    occurred_at=m["occurred_at"],
                    sequence=m["sequence"],
                    acquisition_cost=m["acquisition_cost"],
                )
                for m in inputs
            ],
            method="fifo",
        )
    except (InventoryRefusal, ValueError) as error:
        raise core.InvalidOperation(
            f"Unsupported inventory calculation: {error}"
        ) from error


def _execute(
    session: Session,
    tenant: str,
    request: InventoryReview,
    prepared: dict,
    event,
    action,
    *,
    knowledge_at: datetime | None = None,
) -> dict:
    prior = session.scalar(
        select(CostPolicyRevision)
        .where(
            CostPolicyRevision.tenant_id == tenant,
            CostPolicyRevision.item_id == request.item_id,
        )
        .order_by(CostPolicyRevision.revision.desc())
        .limit(1)
    )
    common = {
        "introduced_event_id": event.id,
        "action_id": action.id,
        "reason": request.reason,
    }
    policy = _new(
        session,
        CostPolicyRevision,
        tenant,
        **common,
        item_id=request.item_id,
        owner_party_id=request.owner_party_id,
        method=request.method,
        currency=request.currency,
        base_unit=request.base_unit,
        history_start=request.history_start,
        revision=prior.revision + 1 if prior else 1,
        supersedes_id=prior.id if prior else None,
    )
    review = _new(
        session,
        CostInventoryReview,
        tenant,
        **common,
        policy_id=policy.id,
        effective_at=request.effective_at,
        target_event_sequence=event.sequence,
        knowledge_at=knowledge_at if knowledge_at is not None else now(),
        algorithm_version=ALGORITHM_VERSION,
        input_schema_version=1,
        content_hash="building",
    )
    for movement in prepared["movements"]:
        basis = session.scalar(
            select(CostMovementBasis).where(
                CostMovementBasis.tenant_id == tenant,
                CostMovementBasis.movement_id == movement["movement_id"],
            )
        )
        if basis is None:
            basis = _new(
                session,
                CostMovementBasis,
                tenant,
                movement_id=movement["movement_id"],
                movement_event_id=movement["movement_event_id"],
                introduced_event_id=event.id,
                movement_type=movement["movement_type"],
                base_quantity=Decimal(movement["quantity"]),
                base_unit=request.base_unit,
                occurred_at=datetime.fromisoformat(movement["occurred_at"]),
                input_schema_version=1,
            )
        chosen = prepared["receipts"].get(basis.movement_id)
        ownership = None
        if chosen:
            previous = session.scalar(
                select(CostOwnershipRevision)
                .where(
                    CostOwnershipRevision.tenant_id == tenant,
                    CostOwnershipRevision.receipt_basis_id
                    == chosen["receipt_basis_id"],
                )
                .order_by(CostOwnershipRevision.revision.desc())
                .limit(1)
            )
            ownership = _new(
                session,
                CostOwnershipRevision,
                tenant,
                **common,
                receipt_basis_id=chosen["receipt_basis_id"],
                owner_party_id=request.owner_party_id,
                evidence_source_record_id=chosen["ownership_source_record_id"],
                covered_quantity=basis.base_quantity,
                revision=previous.revision + 1 if previous else 1,
                supersedes_id=previous.id if previous else None,
            )
        _new(
            session,
            CostInventoryMember,
            tenant,
            review_id=review.id,
            movement_basis_id=basis.id,
            kind=KINDS[basis.movement_type],
            receipt_manifest_id=chosen["manifest_id"] if chosen else None,
            ownership_revision_id=ownership.id if ownership else None,
        )
    payload, _, _ = _inputs(session, tenant, review, policy)
    review.content_hash = _hash(payload)
    session.flush()
    return _read(session, tenant, request.item_id, review_id=review.id)


def _values(row) -> dict:
    def canonical(value):
        if isinstance(value, Decimal):
            return _money(value)
        if isinstance(value, datetime):
            return value.astimezone(UTC).isoformat(timespec="microseconds")
        return value

    return {
        c.name: canonical(getattr(row, c.name))
        for c in row.__table__.columns
        if c.name != "content_hash"
    }


def _inputs(
    session: Session, tenant: str, review, policy
) -> tuple[dict, list[dict], list[dict]]:
    if (
        review.algorithm_version != ALGORITHM_VERSION
        or review.input_schema_version != 1
    ):
        raise core.InvalidOperation("Unsupported inventory review version.")
    members = list(
        session.scalars(
            select(CostInventoryMember)
            .where(
                CostInventoryMember.tenant_id == tenant,
                CostInventoryMember.review_id == review.id,
            )
            .order_by(CostInventoryMember.id)
            .limit(MAX_MOVEMENTS + 1)
        )
    )
    if len(members) > MAX_MOVEMENTS:
        raise core.InvalidOperation("Inventory movement bound exceeded.")
    payload = {"policy": _values(policy), "review": _values(review), "members": []}
    inputs, receipts = [], []
    for member in members:
        basis = _row(session, CostMovementBasis, tenant, member.movement_basis_id)
        source_event = _row(session, BusinessEvent, tenant, basis.movement_event_id)
        if (
            basis.input_schema_version != 1
            or basis.base_unit != policy.base_unit
            or basis.occurred_at > review.effective_at
            or basis.occurred_at < policy.history_start
            or KINDS.get(basis.movement_type) != member.kind
            or source_event.event_type != "movement.recorded"
            or source_event.subject_type != "movement"
            or source_event.subject_id != basis.movement_id
            or source_event.sequence > review.target_event_sequence
        ):
            raise core.InvalidOperation("Inventory input integrity mismatch.")
        retained = {
            "member": _values(member),
            "movement": _values(basis),
            "movement_sequence": source_event.sequence,
        }
        cost = None
        if member.kind == "receipt":
            if len(receipts) >= MAX_RECEIPTS:
                raise core.InvalidOperation("Inventory receipt bound exceeded.")
            ownership = _row(
                session, CostOwnershipRevision, tenant, member.ownership_revision_id
            )
            receipt_basis = _row(
                session, CostReceiptBasis, tenant, ownership.receipt_basis_id
            )
            if (
                ownership.owner_party_id != policy.owner_party_id
                or ownership.covered_quantity != basis.base_quantity
                or receipt_basis.movement_id != basis.movement_id
            ):
                raise core.InvalidOperation("Inventory ownership integrity mismatch.")
            held = receipt_cost(
                session,
                tenant,
                basis.movement_id,
                manifest_id=member.receipt_manifest_id,
            )
            if (
                held["actual_cost"] is None
                or held["currency"] != policy.currency
                or held["base_unit"] != policy.base_unit
            ):
                raise core.InvalidOperation(
                    "Inventory receipt review integrity mismatch."
                )
            cost = held["actual_cost"]
            retained["ownership"] = _values(ownership)
            receipts.append(
                {
                    "movement_id": basis.movement_id,
                    "receipt_manifest_id": member.receipt_manifest_id,
                    "ownership_revision_id": ownership.id,
                    "ownership_source_record_id": ownership.evidence_source_record_id,
                }
            )
        payload["members"].append(retained)
        inputs.append(
            {
                "movement_id": basis.movement_id,
                "movement_type": basis.movement_type,
                "quantity": str(basis.base_quantity),
                "occurred_at": basis.occurred_at.isoformat(),
                "sequence": source_event.sequence,
                "acquisition_cost": cost,
            }
        )
    return payload, inputs, receipts


def _format(value):
    if isinstance(value, Decimal):
        return _money(value)
    if isinstance(value, dict):
        return {k: _format(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_format(v) for v in value]
    return value


def _read(
    session: Session, tenant: str, item_id: str, *, review_id: str | None = None
) -> dict:
    with session.no_autoflush:
        core.get_tenant(session, tenant)
        _row(session, Item, tenant, item_id)
        if review_id:
            review = _row(session, CostInventoryReview, tenant, review_id)
        else:
            review = session.scalar(
                select(CostInventoryReview)
                .join(
                    CostPolicyRevision,
                    (CostPolicyRevision.tenant_id == CostInventoryReview.tenant_id)
                    & (CostPolicyRevision.id == CostInventoryReview.policy_id),
                )
                .where(
                    CostInventoryReview.tenant_id == tenant,
                    CostPolicyRevision.item_id == item_id,
                )
                .order_by(CostPolicyRevision.revision.desc())
                .limit(1)
            )
        if review is None:
            return {
                "item_id": item_id,
                "review_id": None,
                "review_state": "unreviewed",
                "acquisition_value": None,
                "carrying_value": None,
                "consumption": [],
                "missing_basis": ["inventory_scope_not_reviewed"],
                "persistence": {"business_writes": False, "projection_writes": False},
            }
        policy = _row(session, CostPolicyRevision, tenant, review.policy_id)
        if policy.item_id != item_id:
            raise core.NotFound("Costing scope not found.")
        payload, inputs, receipts = _inputs(session, tenant, review, policy)
        if _hash(payload) != review.content_hash:
            raise core.InvalidOperation("Inventory input integrity mismatch.")
        result = _calculate(inputs)
        stale = (
            not review_id and _sequence(session, tenant) > review.target_event_sequence
        )
        consumption = []
        for issue in result.issues:
            row = _format(asdict(issue))
            row["basis_cost"] = row["cost"]
            if stale:
                row["cost"] = None
            consumption.append(row)
        return {
            "item_id": item_id,
            "review_id": review.id,
            "policy_id": policy.id,
            "policy_revision": policy.revision,
            "history_start": policy.history_start.isoformat(),
            "action_id": review.action_id,
            "reason": review.reason,
            "algorithm_version": review.algorithm_version,
            "method": policy.method,
            "owner_party_id": policy.owner_party_id,
            "currency": policy.currency,
            "base_unit": policy.base_unit,
            "effective_at": review.effective_at.isoformat(),
            "knowledge_at": review.knowledge_at.isoformat(),
            "event_sequence": review.target_event_sequence,
            "review_state": "stale" if stale else "reviewed_complete_at_cutoff",
            "missing_basis": ["inventory_review_stale"] if stale else [],
            "remaining_quantity": None if stale else _money(result.remaining_quantity),
            "basis_remaining_quantity": _money(result.remaining_quantity),
            "acquisition_value": None if stale else _money(result.remaining_cost),
            "basis_acquisition_value": _money(result.remaining_cost),
            "carrying_value": None,
            "carrying_value_state": "assessment_not_supported",
            "consumption": None if stale else consumption,
            "remaining": None
            if stale
            else _format([asdict(p) for p in result.remaining]),
            **(
                {
                    "basis_consumption": consumption,
                    "basis_remaining": _format([asdict(p) for p in result.remaining]),
                }
                if stale
                else {}
            ),
            "receipt_sources": receipts,
            "persistence": {"business_writes": False, "projection_writes": False},
        }


def _batch_members(request: InventoryBatchReview) -> list[InventoryReview]:
    return [
        InventoryReview(
            **scope.model_dump(),
            operation="inventory_review",
            expected_event_sequence=request.expected_event_sequence,
            reason=request.reason,
        )
        for scope in sorted(request.scopes, key=lambda scope: scope.item_id)
    ]


def _check_batch(session: Session, tenant: str, request: InventoryBatchReview) -> dict:
    movements = receipts = 0
    rows = []
    for member in _batch_members(request):
        prepared = _check(
            session,
            tenant,
            member,
            movement_limit=MAX_MOVEMENTS - movements,
            receipt_limit=MAX_RECEIPTS - receipts,
        )
        movements += prepared["movement_count"]
        receipts += prepared["receipt_count"]
        rows.append({"item_id": member.item_id, "review": prepared})
    if _sequence(session, tenant) != request.expected_event_sequence:
        raise core.Conflict("Costing preview is stale; reload the held evidence.")
    return {
        "scopes": rows,
        "movement_count": movements,
        "receipt_count": receipts,
    }


def _execute_batch(
    session: Session,
    tenant: str,
    request: InventoryBatchReview,
    prepared: dict,
    event,
    action,
) -> dict:
    # The caller owns the tenant lock/savepoint. One real decision event seals every
    # member; no worker or collection of old reviews can manufacture this authority.
    members = _batch_members(request)
    reviews = [
        _execute(
            session,
            tenant,
            member,
            checked["review"],
            event,
            action,
            knowledge_at=event.recorded_at,
        )
        for member, checked in zip(members, prepared["scopes"], strict=True)
    ]
    return {
        "action_id": action.id,
        "effective_at": members[0].effective_at.isoformat(),
        "knowledge_at": event.recorded_at.astimezone(UTC).isoformat(),
        "event_sequence": event.sequence,
        "reviews": reviews,
    }
