"""Canonical inventory observation at an explicitly pinned tenant/generation."""

from sqlalchemy import Select, select

from reality.db.cost_generations import CostInventorySnapshot


def inventory_relation(tenant_id: str, generation_id: str) -> Select:
    """Never resolve a mutable publication pointer inside the numeric relation."""
    return select(
        CostInventorySnapshot.remaining_quantity,
        CostInventorySnapshot.acquisition_value,
    ).where(
        CostInventorySnapshot.tenant_id == tenant_id,
        CostInventorySnapshot.generation_id == generation_id,
    )
