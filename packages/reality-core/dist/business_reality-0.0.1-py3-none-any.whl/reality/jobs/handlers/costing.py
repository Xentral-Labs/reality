"""Owner-authorized rebuild of one retained inventory review, never financial approval."""

from pydantic import BaseModel, ConfigDict, Field, model_serializer, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from reality.jobs.registry import (
    JobContext,
    JobDefinition,
    JobError,
    JobResult,
    RecordReference,
    require_company_owner,
)


class InventoryConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, str_strip_whitespace=True)
    review_id: str | None = Field(default=None, min_length=1, max_length=128)
    action_id: str | None = Field(default=None, min_length=1, max_length=128)

    @model_validator(mode="after")
    def exact_scope(self):
        if (self.review_id is None) == (self.action_id is None):
            raise ValueError("Exactly one review_id or action_id is required.")
        return self

    @model_serializer
    def serialize_scope(self) -> dict[str, str]:
        # Preserve existing manual-run config fingerprints for review-only requests.
        return (
            {"review_id": self.review_id}
            if self.review_id is not None
            else {"action_id": self.action_id}
        )


def authorize(session: Session, context: JobContext, config: InventoryConfig) -> None:
    from reality.db.inventory_costing import CostInventoryReview

    require_company_owner(session, context, config)
    if config.action_id is not None:
        from reality.services import core
        from reality.services.costing import inventory_batch_snapshot

        try:
            inventory_batch_snapshot(session, context.tenant_id, config.action_id)
        except (core.NotFound, core.InvalidOperation) as error:
            raise JobError("cost_basis_unavailable") from error
        return
    if (
        session.scalar(
            select(CostInventoryReview.id).where(
                CostInventoryReview.tenant_id == context.tenant_id,
                CostInventoryReview.id == config.review_id,
            )
        )
        is None
    ):
        raise JobError("cost_basis_unavailable")


def refresh(
    session: Session, context: JobContext, config: InventoryConfig
) -> JobResult:
    from reality.services.costing import build_inventory_generation

    authorize(session, context, config)
    if config.action_id is not None:
        from reality.services.costing import build_inventory_batch_generation

        result = build_inventory_batch_generation(
            session, context.tenant_id, config.action_id, deadline=context.deadline
        )
        return JobResult(
            counts={
                "generations": result["created"],
                "inventory_rows": result["inventory_rows"],
            },
            references=[
                RecordReference(record_type="cost_inventory_generation", id=identity)
                for identity in result["generation_ids"]
            ],
        )
    result = build_inventory_generation(
        session, context.tenant_id, config.review_id, deadline=context.deadline
    )
    return JobResult(
        counts={"generations": int(result["created"]), "inventory_rows": 1},
        references=[
            RecordReference(
                record_type="cost_inventory_generation", id=result["generation_id"]
            )
        ],
    )


REFRESH_INVENTORY = JobDefinition(
    name="costing.inventory.refresh",
    version=1,
    config_model=InventoryConfig,
    authorize=authorize,
    handler=refresh,
)
