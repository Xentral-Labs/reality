"""Fixed public costing record vocabulary; additions require explicit review."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

# Labels are intentional bilingual product data. No database-driven public allowlist.
RECORDS = {
    "cost_receipt_basis": {
        "labels": ("Receipt cost basis", "Wareneingangs-Kostenbasis"),
        "fields": (
            "movement_id",
            "introduced_event_id",
            "base_quantity",
            "base_unit",
            "input_schema_version",
            "id",
        ),
    },
    "cost_component_basis": {
        "labels": ("Received cost component", "Belegte Kostenkomponente"),
        "fields": (
            "component_id",
            "introduced_event_id",
            "interpretation_outcome_id",
            "evidence_fingerprint",
            "input_schema_version",
            "id",
        ),
    },
    "cost_attribution_revision": {
        "labels": ("Cost allocation revision", "Revision der Kostenzuordnung"),
        "fields": (
            "component_basis_id",
            "revision",
            "supersedes_id",
            "introduced_event_id",
            "action_id",
            "effective_at",
            "reason",
            "state",
            "basis",
            "tax_treatment",
            "selected_basis_tax_inclusion",
            "nonrecoverable_tax_amount",
            "id",
        ),
    },
    "cost_attribution_part": {
        "labels": ("Acquisition cost share", "Anschaffungskostenanteil"),
        "fields": (
            "attribution_revision_id",
            "receipt_basis_id",
            "amount_bucket",
            "category",
            "source_share",
            "cost_effect",
            "assignment_kind",
            "id",
        ),
    },
    "cost_component_replacement": {
        "labels": ("Cost evidence replacement", "Ersatz eines Kostennachweises"),
        "fields": (
            "previous_basis_id",
            "replacement_basis_id",
            "introduced_event_id",
            "action_id",
            "reason",
            "id",
        ),
    },
    "cost_correction_basis": {
        "labels": ("Cost correction basis", "Korrekturgrundlage der Kosten"),
        "fields": (
            "movement_correction_id",
            "introduced_event_id",
            "input_schema_version",
            "id",
        ),
    },
    "cost_input_manifest": {
        "labels": ("Retained cost inputs", "Festgehaltene Kostengrundlagen"),
        "fields": (
            "target_event_sequence",
            "effective_at",
            "knowledge_at",
            "input_schema_version",
            "algorithm_version",
            "state",
            "content_hash",
            "sealed_at",
            "id",
        ),
    },
    "cost_scope_review": {
        "labels": ("Receipt cost review", "Prüfung der Wareneingangskosten"),
        "fields": (
            "receipt_basis_id",
            "revision",
            "supersedes_id",
            "manifest_id",
            "introduced_event_id",
            "action_id",
            "reason",
            "id",
        ),
    },
    "cost_scope_review_category": {
        "labels": ("Acquisition category review", "Prüfung der Anschaffungskostenart"),
        "fields": ("review_id", "category", "disposition", "reason", "id"),
    },
    "cost_manifest_receipt": {
        "labels": ("Retained receipt membership", "Festgehaltener Wareneingang"),
        "fields": ("manifest_id", "receipt_basis_id", "id"),
    },
    "cost_manifest_component": {
        "labels": ("Retained component membership", "Festgehaltene Kostenkomponente"),
        "fields": ("manifest_id", "component_basis_id", "id"),
    },
    "cost_manifest_attribution": {
        "labels": ("Retained allocation membership", "Festgehaltene Kostenzuordnung"),
        "fields": ("manifest_id", "attribution_revision_id", "id"),
    },
    "cost_manifest_correction": {
        "labels": ("Retained correction membership", "Festgehaltene Korrektur"),
        "fields": ("manifest_id", "correction_basis_id", "id"),
    },
    "cost_manifest_replacement": {
        "labels": ("Retained replacement membership", "Festgehaltener Nachweisersatz"),
        "fields": ("manifest_id", "replacement_id", "id"),
    },
    "cost_policy_revision": {
        "labels": ("Valuation policy revision", "Revision der Bewertungsmethode"),
        "fields": (
            "item_id",
            "owner_party_id",
            "revision",
            "supersedes_id",
            "method",
            "currency",
            "base_unit",
            "history_start",
            "introduced_event_id",
            "action_id",
            "reason",
            "id",
        ),
    },
    "cost_movement_basis": {
        "labels": ("Retained stock movement", "Festgehaltene Lagerbewegung"),
        "fields": (
            "movement_id",
            "movement_event_id",
            "introduced_event_id",
            "movement_type",
            "base_quantity",
            "base_unit",
            "occurred_at",
            "input_schema_version",
            "id",
        ),
    },
    "cost_ownership_revision": {
        "labels": (
            "Economic ownership review",
            "Prüfung der wirtschaftlichen Zurechnung",
        ),
        "fields": (
            "receipt_basis_id",
            "owner_party_id",
            "evidence_source_record_id",
            "covered_quantity",
            "revision",
            "supersedes_id",
            "introduced_event_id",
            "action_id",
            "reason",
            "id",
        ),
    },
    "cost_inventory_review": {
        "labels": (
            "Inventory acquisition cost review",
            "Prüfung des Bestands zu Anschaffungskosten",
        ),
        "fields": (
            "policy_id",
            "effective_at",
            "target_event_sequence",
            "knowledge_at",
            "algorithm_version",
            "input_schema_version",
            "content_hash",
            "introduced_event_id",
            "action_id",
            "reason",
            "id",
        ),
    },
    "cost_inventory_member": {
        "labels": ("Retained inventory membership", "Festgehaltene Bestandsgrundlage"),
        "fields": (
            "review_id",
            "movement_basis_id",
            "kind",
            "receipt_manifest_id",
            "ownership_revision_id",
            "id",
        ),
    },
    "cost_revenue_match_basis": {
        "labels": ("Revenue and shipment binding", "Zuordnung von Erlös und Lieferung"),
        "fields": (
            "document_line_id",
            "order_line_id",
            "movement_basis_id",
            "item_id",
            "customer_id",
            "stated_net",
            "quantity",
            "currency",
            "base_unit",
            "invoice_date",
            "sales_channel",
            "evidence_hash",
            "input_schema_version",
            "introduced_event_id",
            "id",
        ),
    },
    "cost_contribution_review": {
        "labels": ("Contribution margin review", "Prüfung des Deckungsbeitrags"),
        "fields": (
            "revenue_basis_id",
            "inventory_member_id",
            "revision",
            "supersedes_id",
            "profile",
            "economic_at",
            "knowledge_at",
            "introduced_event_id",
            "event_sequence",
            "action_id",
            "reason",
            "content_hash",
            "id",
        ),
    },
    "cost_selling_attribution_part": {
        "labels": ("Selling cost share", "Vertriebskostenanteil"),
        "fields": (
            "attribution_revision_id",
            "document_line_id",
            "category",
            "source_share",
            "cost_effect",
            "assignment_kind",
            "id",
        ),
    },
    "cost_selling_review_category": {
        "labels": ("Selling category review", "Prüfung der Vertriebskostenart"),
        "fields": ("review_id", "category", "disposition", "reason", "id"),
    },
    "cost_selling_review_member": {
        "labels": (
            "Retained selling membership",
            "Festgehaltener Vertriebskostenanteil",
        ),
        "fields": ("review_id", "part_id", "id"),
    },
    "financial_component": {
        "labels": ("Received financial amounts", "Belegte Finanzbeträge"),
        "fields": (
            "id",
            "document_id",
            "document_line_id",
            "stated_net",
            "stated_tax",
            "stated_gross",
            "stated_base",
            "currency",
        ),
    },
    "action": {
        "labels": ("Recorded decision", "Aufgezeichnete Entscheidung"),
        "fields": (
            "id",
            "type",
            "status",
            "actor_type",
            "created_at",
            "decided_at",
            "decided_by_user_id",
        ),
    },
    "movement_correction": {
        "labels": ("Stock movement correction", "Korrektur der Lagerbewegung"),
        "fields": (
            "id",
            "original_movement_id",
            "compensating_movement_id",
            "replacement_movement_id",
            "reason",
        ),
    },
    "interpretation_outcome": {
        "labels": (
            "Source interpretation result",
            "Ergebnis der Quelleninterpretation",
        ),
        "fields": (
            "id",
            "source_record_id",
            "classification",
            "interpreter_name",
            "interpreter_version",
            "reason_code",
            "summary",
            "completed_at",
        ),
    },
}
COST_KINDS = tuple(kind for kind in RECORDS if kind.startswith("cost_"))


class CostRecordRead(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    kind: str = Field(min_length=1)
    record_id: str = Field(min_length=1)
    page: int = Field(default=1, ge=1, le=10000, strict=True)
    language: Literal["en", "de", "nl", "es"] = "en"
