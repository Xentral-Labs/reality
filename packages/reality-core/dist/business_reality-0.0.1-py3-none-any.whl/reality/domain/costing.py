"""Typed receipt-cost decisions; received amounts retain their original signs."""

from datetime import UTC, datetime
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    TypeAdapter,
    field_validator,
    model_validator,
)

CATEGORIES = (
    "goods",
    "inbound_freight",
    "duty",
    "other_acquisition",
    "purchase_reduction",
    "nonrecoverable_tax",
)
Category = Literal[
    "goods",
    "inbound_freight",
    "duty",
    "other_acquisition",
    "purchase_reduction",
    "nonrecoverable_tax",
]
Amount = Annotated[Decimal, Field(max_digits=18, decimal_places=4, allow_inf_nan=False)]


class Request(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class CostPart(Request):
    movement_id: str = Field(min_length=1)
    category: Category
    source_share: Amount
    cost_effect: Literal[-1, 1]
    amount_bucket: Literal["selected_basis", "nonrecoverable_tax"] = "selected_basis"
    assignment_kind: Literal["direct", "allocated"] = "direct"

    @model_validator(mode="after")
    def semantic_effect(self):
        if self.source_share == 0:
            raise ValueError(
                "Zero belongs in an explicit scope review, not an allocation part."
            )
        if self.category != "nonrecoverable_tax" and self.cost_effect != (
            -1 if self.category == "purchase_reduction" else 1
        ):
            raise ValueError("Cost effect contradicts the selected category.")
        if (self.amount_bucket == "nonrecoverable_tax") != (
            self.category == "nonrecoverable_tax"
        ):
            raise ValueError("Tax parts require the independent received-tax bucket.")
        return self


def contribution(part: CostPart) -> Decimal:
    return abs(part.source_share) * part.cost_effect


def validate_shares(parts: list[CostPart], basis: Decimal, tax: Decimal) -> None:
    seen = set()
    for bucket, capacity in (("selected_basis", basis), ("nonrecoverable_tax", tax)):
        selected = [p for p in parts if p.amount_bucket == bucket]
        for part in selected:
            key = (part.movement_id, part.category, bucket)
            if key in seen:
                raise ValueError("Duplicate target/category/bucket.")
            seen.add(key)
            if capacity == 0 or (part.source_share > 0) != (capacity > 0):
                raise ValueError("Shares must preserve their source bucket sign.")
        if sum((abs(p.source_share) for p in selected), Decimal(0)) > abs(capacity):
            raise ValueError("Assigned shares exceed the received bucket.")

    for part in parts:
        if part.amount_bucket != "nonrecoverable_tax":
            continue
        effects = {
            p.cost_effect
            for p in parts
            if p.movement_id == part.movement_id and p.amount_bucket == "selected_basis"
        }
        if effects and effects != {part.cost_effect}:
            raise ValueError(
                "Tax cost direction must follow the selected amount for the same receipt."
            )


class Change(Request):
    expected_event_sequence: int = Field(ge=0)
    reason: str = Field(min_length=1, max_length=4000)


class Assign(Change):
    operation: Literal["assign"]
    document_id: str = Field(min_length=1)
    document_line_id: str | None = None
    expected_evidence_hash: str = Field(min_length=64, max_length=64)
    basis: Literal["net", "gross", "base"]
    selected_basis_tax_inclusion: Literal["included", "excluded", "unknown"]
    tax_treatment: Literal[
        "recoverable", "nonrecoverable", "mixed", "not_applicable", "unknown"
    ]
    nonrecoverable_tax_amount: Amount = Decimal(0)
    parts: list[CostPart] = Field(min_length=1, max_length=100)


class CategoryReview(Request):
    category: Category
    disposition: Literal["evidenced", "confirmed_zero", "not_applicable", "unresolved"]
    reason: str = Field(min_length=1, max_length=4000)


class Review(Change):
    operation: Literal["review"]
    movement_id: str = Field(min_length=1)
    categories: list[CategoryReview] = Field(min_length=6, max_length=6)

    @field_validator("categories")
    @classmethod
    def every_category(cls, values):
        if {v.category for v in values} != set(CATEGORIES):
            raise ValueError("Review every required category exactly once.")
        return values


class Replace(Assign):
    operation: Literal["replace"]
    previous_component_basis_id: str = Field(min_length=1)


class Withdraw(Change):
    operation: Literal["withdraw"]
    component_basis_id: str = Field(min_length=1)


class InventoryReceipt(Request):
    movement_id: str = Field(min_length=1)
    manifest_id: str = Field(min_length=1)
    ownership_source_record_id: str = Field(min_length=1)


class InventoryScope(Request):
    item_id: str = Field(min_length=1)
    owner_party_id: str = Field(min_length=1)
    method: Literal["fifo"]
    currency: str = Field(min_length=3, max_length=3)
    base_unit: str = Field(min_length=1)
    history_start: AwareDatetime
    effective_at: AwareDatetime
    history_complete_from_zero: Literal[True]
    receipt_cost_scopes_confirmed: Literal[True]
    economic_issue_ids: list[str] = Field(max_length=100)
    receipts: list[InventoryReceipt] = Field(min_length=1, max_length=20)

    @field_validator("history_start", "effective_at")
    @classmethod
    def utc_inventory_time(cls, value: datetime) -> datetime:
        return value.astimezone(UTC)

    @model_validator(mode="after")
    def exact_scope(self):
        if self.history_start > self.effective_at:
            raise ValueError("History start exceeds the valuation cutoff.")
        if len(set(self.economic_issue_ids)) != len(self.economic_issue_ids):
            raise ValueError("Duplicate economic issue identity.")
        if len({r.movement_id for r in self.receipts}) != len(self.receipts):
            raise ValueError("Duplicate receipt identity.")
        return self


class InventoryReview(InventoryScope, Change):
    operation: Literal["inventory_review"]


class InventoryBatchReview(Change):
    operation: Literal["inventory_batch_review"]
    scopes: list[InventoryScope] = Field(min_length=2, max_length=10)

    @model_validator(mode="after")
    def compatible_scopes(self):
        if sum(len(scope.receipts) for scope in self.scopes) > 20:
            raise ValueError("Joint inventory receipt bound exceeded.")
        if len({scope.item_id for scope in self.scopes}) != len(self.scopes):
            raise ValueError("Duplicate inventory item scope.")
        for field in ("effective_at", "owner_party_id", "currency"):
            if len({getattr(scope, field) for scope in self.scopes}) != 1:
                raise ValueError(f"Joint inventory scopes require the same {field}.")
        return self


class InventoryRead(Request):
    item_id: str = Field(min_length=1)
    review_id: str | None = None


SELLING_CATEGORIES = (
    "outbound_freight",
    "fulfilment",
    "packaging",
    "payment_fee",
    "marketplace_commission",
    "sales_commission",
    "other_selling",
)
SellingCategory = Literal[
    "outbound_freight",
    "fulfilment",
    "packaging",
    "payment_fee",
    "marketplace_commission",
    "sales_commission",
    "other_selling",
]


class SellingPart(Request):
    document_line_id: str = Field(min_length=1)
    category: SellingCategory
    source_share: Amount
    cost_effect: Literal[-1, 1]
    assignment_kind: Literal["direct", "allocated"] = "direct"

    @field_validator("source_share")
    @classmethod
    def nonzero(cls, value):
        if value == 0:
            raise ValueError("Zero requires a scope review.")
        return value


class SellingAssign(Change):
    operation: Literal["selling_assign"]
    document_id: str = Field(min_length=1)
    document_line_id: str | None = None
    expected_evidence_hash: str = Field(min_length=64, max_length=64)
    tax_treatment: Literal["recoverable", "not_applicable"]
    selling_expense_confirmed: Literal[True]
    parts: list[SellingPart] = Field(min_length=1, max_length=100)

    @field_validator("parts")
    @classmethod
    def unique_parts(cls, values):
        if len({(p.document_line_id, p.category) for p in values}) != len(values):
            raise ValueError("Duplicate selling target/category.")
        return values


class SellingCategoryReview(Request):
    category: SellingCategory
    disposition: Literal["evidenced", "confirmed_zero", "not_applicable", "unresolved"]
    reason: str = Field(min_length=1, max_length=4000)


class ContributionReview(Change):
    operation: Literal["contribution_review"]
    document_line_id: str = Field(min_length=1)
    expected_candidate_hash: str = Field(min_length=64, max_length=64)
    profile: Literal["commercial_v1"]
    profile_confirmed: Literal[True]
    revenue_complete: Literal[True]
    economic_at: AwareDatetime
    selling_categories: list[SellingCategoryReview] | None = None

    @field_validator("selling_categories")
    @classmethod
    def every_selling_category(cls, values):
        if values is not None and (
            len(values) != len(SELLING_CATEGORIES)
            or {v.category for v in values} != set(SELLING_CATEGORIES)
        ):
            raise ValueError("Review every selling category exactly once.")
        return values

    @field_validator("economic_at")
    @classmethod
    def utc_economic_time(cls, value: datetime) -> datetime:
        return value.astimezone(UTC)


CHANGE = TypeAdapter(
    Annotated[
        Assign
        | Review
        | Replace
        | Withdraw
        | InventoryReview
        | InventoryBatchReview
        | ContributionReview
        | SellingAssign,
        Field(discriminator="operation"),
    ]
)


class ReceiptRead(Request):
    movement_id: str = Field(min_length=1)
    manifest_id: str | None = None


class EvidenceRead(Request):
    document_id: str = Field(min_length=1)
    document_line_id: str | None = None


class ContributionRead(Request):
    document_line_id: str = Field(min_length=1)


class ReviewedContributionRead(Request):
    document_line_id: str = Field(min_length=1)
    review_id: str | None = None
