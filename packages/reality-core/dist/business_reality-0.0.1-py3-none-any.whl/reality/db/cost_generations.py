"""Disposable, atomically published observations of retained inventory reviews."""

from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    CheckConstraint,
    ForeignKeyConstraint,
    Numeric,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from reality.db.core import Base, UTCDateTime
from reality.db.costing import CostRecord, _link


class CostInventoryGeneration(CostRecord, Base):
    __tablename__ = "cost_inventory_generation"
    __table_args__ = (
        UniqueConstraint("tenant_id", "id"),
        UniqueConstraint("tenant_id", "review_id", "id"),
        UniqueConstraint("tenant_id", "review_id", "algorithm_version"),
        _link("review_id", "cost_inventory_review"),
        CheckConstraint(
            "algorithm_version='inventory-v1' AND length(output_hash)=64",
            name="ck_inventory_generation_version",
        ),
    )
    review_id: Mapped[str] = mapped_column(String)
    algorithm_version: Mapped[str] = mapped_column(String)
    completed_at: Mapped[datetime] = mapped_column(UTCDateTime)
    output_hash: Mapped[str] = mapped_column(String(64))


class CostInventorySnapshot(CostRecord, Base):
    __tablename__ = "cost_inventory_snapshot"
    __table_args__ = (
        UniqueConstraint("tenant_id", "id"),
        UniqueConstraint("tenant_id", "generation_id"),
        _link("generation_id", "cost_inventory_generation"),
        CheckConstraint(
            "remaining_quantity>=0 AND acquisition_value>=0",
            name="ck_inventory_snapshot_amounts",
        ),
    )
    generation_id: Mapped[str] = mapped_column(String)
    remaining_quantity: Mapped[Decimal] = mapped_column(Numeric(18, 4))
    acquisition_value: Mapped[Decimal] = mapped_column(Numeric(18, 4))


class CostInventoryPublication(CostRecord, Base):
    __tablename__ = "cost_inventory_publication"
    __table_args__ = (
        UniqueConstraint("tenant_id", "id"),
        UniqueConstraint("tenant_id", "review_id"),
        _link("review_id", "cost_inventory_review"),
        ForeignKeyConstraint(
            ["tenant_id", "review_id", "generation_id"],
            [
                "cost_inventory_generation.tenant_id",
                "cost_inventory_generation.review_id",
                "cost_inventory_generation.id",
            ],
        ),
    )
    review_id: Mapped[str] = mapped_column(String)
    generation_id: Mapped[str] = mapped_column(String)
